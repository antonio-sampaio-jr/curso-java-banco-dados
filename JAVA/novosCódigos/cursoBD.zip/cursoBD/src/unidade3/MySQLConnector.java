package unidade3;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class MySQLConnector {
	
	String url = "jdbc:mysql://localhost:3306/curso_java";
	String usuario = "root";
	String senha = "lea@1990";
	Connection conexao;

	public void conectar() throws SQLException
	{
		conexao = DriverManager.getConnection(url,usuario,senha);
	}
	
	//CRUD - Tabela Cliente
	
	public void consultarClientes() throws HeadlessException, SQLException
	{
		Statement statement = conexao.createStatement();
		String consulta = "SELECT * FROM Cliente";
		ResultSet rs = statement.executeQuery(consulta);
		while(rs.next()) {   
			JOptionPane.showMessageDialog(null, "cpf:"+rs.getLong(1)+
		       " nome:"+ rs.getString(2)+ " email"+ rs.getString(3));
		}
	}
	
	public boolean consultarClienteAux(long cpf) throws SQLException
	{
		String consulta = "SELECT * FROM Cliente where cpf=?";
		PreparedStatement pstatement = conexao.prepareStatement(consulta);
		pstatement.setLong(1, cpf);
		ResultSet rs = pstatement.executeQuery();
		if (!rs.next())
			return true;
		else
			return false;
	}
	
	public void consultarCliente(long cpf) throws SQLException
	{
		String consulta = "SELECT * FROM Cliente where cpf=?";
		PreparedStatement pstatement = conexao.prepareStatement(consulta);
		pstatement.setLong(1, cpf);
		ResultSet rs = pstatement.executeQuery();
		if (!rs.next())
			System.out.println("Cliente Inexistente!");
		else
		{
			JOptionPane.showMessageDialog(null, "cpf:"+rs.getLong(1)+
				       " nome:"+ rs.getString(2)+ " email"+ rs.getString(3));
		}
	}
	
	public void inserirCliente() throws SQLException
	{
		//Entrada de dados
		long cpf = Long.parseLong(JOptionPane.showInputDialog("Digite o cpf"));
		boolean prosseguir = this.consultarClienteAux(cpf);
		
		if(prosseguir)
		{	
			String nome = JOptionPane.showInputDialog("Digite o nome");
			String email = JOptionPane.showInputDialog("Digite o email");
			String consulta = "INSERT INTO Cliente (cpf,nome,email) values (?,?,?)";
			PreparedStatement pstatement = conexao.prepareStatement(consulta);
			pstatement.setLong(1, cpf);
			pstatement.setString(2, nome);
			pstatement.setString(3, email);
			pstatement.executeUpdate();
			System.out.println("Cliente inserido com Sucesso!");	
		}
		else
			System.out.println("Falha ao inserir o cliente - CPF já existente! Tente outro número");
	}
	
	public void excluirCliente(long cpf) throws SQLException
	{
		boolean prosseguir = this.consultarClienteAux(cpf);

		if(!prosseguir)
		{	
			String consulta = "DELETE FROM Cliente WHERE cpf = ?";
			PreparedStatement pstatement = conexao.prepareStatement(consulta);
			pstatement.setLong(1, cpf);
			pstatement.executeUpdate();
			System.out.println("Cliente excluído com Sucesso!");	
		}
		else
			System.out.println("Falha ao excluir o cliente - CPF inexistente!");

	}
	
	public void alterarCliente(long cpf) throws SQLException
	{
		boolean prosseguir = this.consultarClienteAux(cpf);

		if(!prosseguir)
		{	
			String nome = JOptionPane.showInputDialog("Digite o nome");
			String email = JOptionPane.showInputDialog("Digite o email");
			String consulta = "update Cliente SET nome = ?, email = ? WHERE cpf = ?";
			PreparedStatement pstatement = conexao.prepareStatement(consulta);
			pstatement.setString(1, nome);
			pstatement.setString(2, email);
			pstatement.setLong(3, cpf);
			pstatement.executeUpdate();
			System.out.println("Cliente alterado com Sucesso!");	
		}
		else
			System.out.println("Falha ao alterar o cliente - CPF inexistente!");
	}
	
	public static void main(String[] args) 
	{
		MySQLConnector mysql = new MySQLConnector();
		
		try {
			mysql.conectar();
			//mysql.consultarCliente(12345678901l);
			mysql.excluirCliente(12345678901l);
			//mysql.inserirCliente();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
