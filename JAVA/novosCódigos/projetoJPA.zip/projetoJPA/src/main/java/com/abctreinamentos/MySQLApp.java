package com.abctreinamentos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.swing.JOptionPane;

public class MySQLApp implements MySQLClienteAPI{

	EntityManagerFactory emf; 
	EntityManager em; 
	EntityTransaction tx; 
	
	public void conectar()
	{
		emf = Persistence.createEntityManagerFactory("JPA");
		em = emf.createEntityManager();
		tx = em.getTransaction();
	}
	
	public void desconectar()
	{
		em.close();
		emf.close();
	}

	@Override
	public void consultarClientes() {
		TypedQuery<Cliente> query = em.createQuery(""
				+ "Select c from Cliente c",Cliente.class);
				List<Cliente> clientes = query.getResultList();
				clientes.forEach(System.out::println);		
	}

	@Override
	public void consultarCliente(String cpf) {
		Cliente cliente = em.find(Cliente.class,cpf);
		if(cliente != null)
			System.out.println(cliente);
		else
			System.out.println("Cliente Inexistente!");
	}

	@Override
	public boolean consultarClienteAux(String cpf) {
		Cliente cliente = em.find(Cliente.class,cpf);
		if (cliente == null)
			return true;
		else
			return false;
	}

	@Override
	public void cadastrarCliente() {
		String cpf = JOptionPane.showInputDialog("Digite o cpf");
		boolean prosseguir = this.consultarClienteAux(cpf);
		if(prosseguir)
		{ 
			String nome = JOptionPane.showInputDialog("Digite o nome");
			String email = JOptionPane.showInputDialog("Digite o email");
			Cliente cliente = new Cliente(cpf,nome,email);
			tx.begin();
			em.persist(cliente);
			tx.commit(); 
			System.out.println("Cliente inserido com Sucesso!"); 
		}
		else
			System.out.println("Falha ao inserir o cliente - CPF já existente!");
		
	}

	@Override
	public void alterarCliente(String cpf) {
		boolean prosseguir = this.consultarClienteAux(cpf);

		if(!prosseguir)
		{ 
			String nome = JOptionPane.showInputDialog("Digite o nome");
			String email = JOptionPane.showInputDialog("Digite o email");
			Cliente cliente = new Cliente(cpf,nome,email);
			tx.begin();
			em.merge(cliente);
			tx.commit(); 
			System.out.println("Cliente alterado com Sucesso!"); 
		}
		else
			System.out.println("Falha ao alterar o cliente - CPF inexistente!");
	}

	@Override
	public void excluirCliente(String cpf) {
		boolean prosseguir = this.consultarClienteAux(cpf);
		if(!prosseguir)
		{ 
			Cliente cliente = em.find(Cliente.class,cpf);
			tx.begin();
			em.remove(cliente);
			tx.commit(); 
			System.out.println("Cliente excluído com Sucesso!"); 
		}
		else
			System.out.println("Falha ao excluir o cliente - CPF inexistente!"); 
	}
	
	public static void main(String[] args) {
		MySQLApp mysql = new MySQLApp();
		mysql.conectar();
		//mysql.consultarClientes();
		//mysql.consultarCliente("123");
		//mysql.cadastrarCliente();
		//mysql.alterarCliente("1234");
		mysql.excluirCliente("1234");
		mysql.desconectar();
	}
}
