package com.abctreinamentos;

public interface MySQLClienteAPI {
	public void consultarClientes();
	public void consultarCliente(String cpf);
	public boolean consultarClienteAux(String cpf);
	public void cadastrarCliente();
	public void alterarCliente(String cpf);
	public void excluirCliente(String cpf);
}

