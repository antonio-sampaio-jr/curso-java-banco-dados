package unidade3;

import javax.swing.JOptionPane;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoDBConnector {
	
	String url = "mongodb://localhost:27017";
	String banco = "test";
	String colecao = "funcionarios";
	MongoClient clienteMongo;
    MongoDatabase bancodedados;
    MongoCollection<Document> funcionariosCollection;
	
	public void conectar() 
	{
		clienteMongo = MongoClients.create(url);
        // Acessar o banco de dados desejado
        bancodedados = clienteMongo.getDatabase(banco);      
        funcionariosCollection = bancodedados.getCollection(colecao);
	}
	
	//CRUD - Coleção Funcionários
	
	public void consultarFuncionarios() 
	{
		// Consulta para obter todos os funcionários
        FindIterable<Document> funcionarios = funcionariosCollection.find();
        funcionarios.forEach(funcionario -> System.out.println(funcionario.toJson()));
	}
	
	public void consultarFuncionario(String id) 
	{
		Document consulta = new Document("_id",new ObjectId(id));
		Document funcionarioEncontrado = funcionariosCollection.find(consulta).first();
		
		if(funcionarioEncontrado != null)
			System.out.println("Funcionário Encontrado:"+funcionarioEncontrado.toJson());
		else
			System.out.println("Funcionário Não Encontrado");
		
	}
	
	public void inserirFuncionario()
	{
		String nome = JOptionPane.showInputDialog("Digite o nome");
		int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a idade"));
		String cargo = JOptionPane.showInputDialog("Digite o cargo");
		String departamento = JOptionPane.showInputDialog("Digite o departamento");
		String cidade = JOptionPane.showInputDialog("Digite a cidade");
		String estado = JOptionPane.showInputDialog("Digite o estado");
		String formatoTrabalho = JOptionPane.showInputDialog("Digite o Formato de Trabalho");
		int salario = Integer.parseInt(JOptionPane.showInputDialog("Digite o salário"));
		
		Document novoFuncionario = new Document("nome",nome).append("idade",idade)
				.append("cargo", cargo).append("departamento", departamento).append("cidade", cidade)
				.append("estado",estado).append("formatoTrabalho",formatoTrabalho).append("salario", salario);
		
		funcionariosCollection.insertOne(novoFuncionario);
		System.out.println("Funcionário Cadastrado com Sucesso!");
				
	}
	
	public void excluirFuncionario(String id)
	{
		Document consulta = new Document("_id",new ObjectId(id));
		Document funcionarioEncontrado = funcionariosCollection.find(consulta).first();
		
		if(funcionarioEncontrado != null)
		{
			funcionariosCollection.deleteOne(funcionarioEncontrado);
			System.out.println("Funcionário Excluído com Sucesso!");
		}	
		else
			System.out.println("Funcionário Não Encontrado");
	}
	
	public void alterarFuncionario(String id)
	{
		Document consulta = new Document("_id",new ObjectId(id));
		Document funcionarioEncontrado = funcionariosCollection.find(consulta).first();
		
		if(funcionarioEncontrado != null)
		{
			String novoCargo = JOptionPane.showInputDialog("Digite o novo cargo");
			String novoSalario = JOptionPane.showInputDialog("Digite o novo salário");
			Document atualizacoes = new Document("$set",new Document().
					append("cargo", novoCargo).append("salario", novoSalario));
			funcionariosCollection.updateOne(consulta, atualizacoes);
			System.out.println("Funcionário Atualizado com Sucesso!");
		}	
		else
			System.out.println("Funcionário Não Encontrado");
	}
	
	public static void main(String[] args) 
	{
		MongoDBConnector mongo = new MongoDBConnector();
		
		try {
			mongo.conectar();
			//mongo.consultarFuncionarios();
			//mongo.excluirFuncionario("64ff5dcbcf73bf0ed2421693");
			mongo.inserirFuncionario();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} 

}
